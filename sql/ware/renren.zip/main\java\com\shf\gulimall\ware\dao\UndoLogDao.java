package com.shf.gulimall.ware.dao;

import com.shf.gulimall.ware.entity.UndoLogEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author shuhongfan
 * @email shuhongfan@foxmail.com
 * @date 2022-05-24 09:57:14
 */
@Mapper
public interface UndoLogDao extends BaseMapper<UndoLogEntity> {
	
}
